package com.kaibook.anzfloor;

import com.kaibook.anzfloor.mapper.CartMapper;
import com.kaibook.anzfloor.service.BookService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class AnzfloorApplicationTests {
	@Autowired
	private BookService bookService;
	@Test
	public void findBookList() {
		bookService.list().forEach(System.out::println);
	}

	@Autowired
	private CartMapper cartMapper;

	@Test
	public void findCartList() {cartMapper.findCartListByUserId(6).forEach(System.out::println);}

}
