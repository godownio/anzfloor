package com.kaibook.anzfloor.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kaibook.anzfloor.entity.OrderItem;
import com.kaibook.anzfloor.mapper.OrderItemMapper;
import org.springframework.stereotype.Service;


@Service
public class OrderItemService extends ServiceImpl<OrderItemMapper, OrderItem> {
}
