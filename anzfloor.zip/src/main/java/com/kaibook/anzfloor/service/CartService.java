package com.kaibook.anzfloor.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kaibook.anzfloor.entity.Cart;
import com.kaibook.anzfloor.entity.CartVo;
import com.kaibook.anzfloor.entity.UserCartVo;
import com.kaibook.anzfloor.mapper.CartMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@Service
public class CartService extends ServiceImpl<CartMapper, Cart> {
    @Autowired
    private CartMapper cartMapper;

    public List<CartVo> findCartByUser(Integer userId){
        return cartMapper.findCartListByUserId(userId);
    }

    //根据购物车id查询对应记录
    public List<CartVo> findCartByIds(List<String> ids){
        return cartMapper.findCartListByIds(ids);
    }



    //统计购物车总计
    public double getCartItemTotal(List<CartVo> list){
        double sum=0.0;
        BigDecimal difsum = new BigDecimal(Double.toString(sum));
        for(CartVo cart:list){
            BigDecimal price = new BigDecimal(Double.toString(cart.getNewPrice()));
            BigDecimal count = new BigDecimal(Integer.toString(cart.getCount()));
            difsum = difsum.add(price.multiply(count));
        }
        return difsum.doubleValue();
    }

    public String deleteByIds(String ids){
        if(ids!=null) {
            String[] id = ids.split(",");
            cartMapper.deleteBatchIds(Arrays.asList(id));
        }
        return "success";
    }
}
