package com.kaibook.anzfloor.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kaibook.anzfloor.entity.Book;
import com.kaibook.anzfloor.mapper.BookMapper;
import org.springframework.stereotype.Service;

@Service
public class BookService extends ServiceImpl<BookMapper, Book> {

}
