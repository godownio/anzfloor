package com.kaibook.anzfloor.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.kaibook.anzfloor.entity.Address;
import com.kaibook.anzfloor.mapper.AddressMapper;
import org.springframework.stereotype.Service;


@Service
public class AddressService extends ServiceImpl<AddressMapper, Address> {
}
