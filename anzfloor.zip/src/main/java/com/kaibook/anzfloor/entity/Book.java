package com.kaibook.anzfloor.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.kaibook.anzfloor.entity.enums.Category;
import com.kaibook.anzfloor.entity.enums.Suit;
import lombok.Data;

import java.util.Calendar;
import java.util.Date;

//对应数据库的bs_book,图书实体类
@Data
//Data注解自动生成setter,getter,toString方法
@TableName(value = "bs_book")
public class Book extends Model<Book> {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String isbn;
    private String name;
    private String author;
    private String publisher;
    private Date publishDate;
    private double oldPrice;
    private double newPrice;
    private String authorLoc;
    private Suit suit;//套装
    private Category category;//图书的主页分类
    private String info;
    private String imgUrl;

}
