package com.kaibook.anzfloor.entity;

import lombok.Data;

@Data
public class UserCartVo {
    private Integer num;
    private double totalPrice;
}
