package com.kaibook.anzfloor.entity.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;

import lombok.Getter;

@Getter
public enum Suit {
    YES(1,"是套装"),NO(2,"不是套装");
    Suit(int code, String descp) {
        this.code = code;
        this.descp = descp;
    }

    @EnumValue//标记数据库存的值是code
    private final int code;
    private final String descp;
    //。。。
}
