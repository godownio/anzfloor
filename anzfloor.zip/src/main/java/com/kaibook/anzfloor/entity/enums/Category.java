package com.kaibook.anzfloor.entity.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;

public enum Category {
    Selected(1,"精选图书"),RECOMMENED(2,"推荐图书"),BARGAIN(3,"特价图书");
    Category(int code, String descp) {
        this.code = code;
        this.descp = descp;
    }

    @EnumValue//标记数据库存的值是code
    private final int code;
    private final String descp;
    //。。。
}
