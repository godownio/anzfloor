package com.kaibook.anzfloor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaibook.anzfloor.entity.Book;

public interface BookMapper extends BaseMapper<Book> {

}
