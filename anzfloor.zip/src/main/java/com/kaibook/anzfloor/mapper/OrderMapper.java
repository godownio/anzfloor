package com.kaibook.anzfloor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaibook.anzfloor.entity.Order;
import com.kaibook.anzfloor.entity.OrderQueryVo;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;


@Mapper
public interface OrderMapper extends BaseMapper<Order> {
    /**
     * 根据用户id查询用户订单以及订单明细
     */
//    List<Order> findOrderAndOrderDetailListByUser(@Param("userId") Integer id, @Param("begin")Integer begin, @Param("end")Integer end);
    List<Order> findOrderAndOrderDetailListByUser(OrderQueryVo orderQueryVo);

    /**
     * 查询记录总数
     */
    Integer findOrderCountByUser(OrderQueryVo orderQueryVo);
}
