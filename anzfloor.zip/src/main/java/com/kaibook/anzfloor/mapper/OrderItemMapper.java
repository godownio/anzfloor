package com.kaibook.anzfloor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaibook.anzfloor.entity.OrderItem;


public interface OrderItemMapper extends BaseMapper<OrderItem> {
}
