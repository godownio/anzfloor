package com.kaibook.anzfloor.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaibook.anzfloor.entity.User;
import org.apache.ibatis.annotations.Mapper;


public interface UserMapper extends BaseMapper<User> {

}
