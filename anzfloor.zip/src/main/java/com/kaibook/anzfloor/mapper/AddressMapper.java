package com.kaibook.anzfloor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.kaibook.anzfloor.entity.Address;


public interface AddressMapper extends BaseMapper<Address> {
}
