/*
 Navicat Premium Data Transfer

 Source Server         : mysqlbook
 Source Server Type    : MySQL
 Source Server Version : 80033
 Source Host           : localhost:3306
 Source Schema         : anzfloor

 Target Server Type    : MySQL
 Target Server Version : 80033
 File Encoding         : 65001

 Date: 27/06/2023 10:23:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bs_address
-- ----------------------------
DROP TABLE IF EXISTS `bs_address`;
CREATE TABLE `bs_address`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `province` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `area` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `detail_address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `email_code` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `receiver` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `tel` varchar(11) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `is_default` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_user_id`(`user_id` ASC) USING BTREE,
  CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `bs_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_address
-- ----------------------------
INSERT INTO `bs_address` VALUES (1, 1, '江苏省', '苏州市', '姑苏区', '姑苏区', '215000', 'edwarder Zhang', '1525000000', '0');
INSERT INTO `bs_address` VALUES (2, 1, '北京市', '北京市', '东城区', '11', '', '', '', '0');
INSERT INTO `bs_address` VALUES (3, 1, '北京市', '北京市', '东城区', '111', '', '', '', '0');
INSERT INTO `bs_address` VALUES (4, 1, '北京市', '北京市', '东城区', '2312312', '', '', '', '0');
INSERT INTO `bs_address` VALUES (5, 1, '北京市', '北京市', '东城区', '123123123', '', '', '', '0');
INSERT INTO `bs_address` VALUES (6, 1, '北京市', '北京市', '东城区', '12312', '', '', '', '1');
INSERT INTO `bs_address` VALUES (7, 6, '河北省', '石家庄市', '长安区', '长安区', '511515', '刘洪开', '1838000000', '1');
INSERT INTO `bs_address` VALUES (8, 6, '北京市', '北京市', '东城区', '1321', '1232', 'lhk', '12312', '0');
INSERT INTO `bs_address` VALUES (9, 10, '北京市', '北京市', '东城区', '13213', '132', '1321', '1321', '0');
INSERT INTO `bs_address` VALUES (10, 6, '北京市', '北京市', '东城区', '213', '1321', '21321', '213213', '0');

-- ----------------------------
-- Table structure for bs_book
-- ----------------------------
DROP TABLE IF EXISTS `bs_book`;
CREATE TABLE `bs_book`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `isbn` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `author` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `publisher` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `publish_date` datetime NULL DEFAULT NULL,
  `old_price` decimal(10, 2) NULL DEFAULT NULL,
  `new_price` decimal(10, 2) NULL DEFAULT NULL,
  `author_loc` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `suit` int NULL DEFAULT NULL,
  `category` int NULL DEFAULT NULL,
  `info` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `img_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 162 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_book
-- ----------------------------
INSERT INTO `bs_book` VALUES (1, '9787121395505', ' 网络安全攻防技术实战', '闵海钊,李合鹏,等', '电子工业出版社', '2020-09-01 00:00:00', 78.00, 39.00, '中国', 1, 1, '奇安信是国内领先的网络安全企业，本书由奇安信高手团队写作，是其官方培训教材之一。技术领先，内容详实。', '29136921-1_u_3.jpg');
INSERT INTO `bs_book` VALUES (2, '9787121418679', '网络安全渗透测试', '苗春雨,曹雅斌,等', '电子工业出版社', '2021-08-01 00:00:00', 125.00, 62.50, '中国', 1, 1, '本书是中国网络安全审查技术与认证中心注册渗透测试人员认证（Licensed Penetration Tester， LPT）考试的配套教材，深入浅出地全面介绍了渗透测试的完整流程、原理知识和实用技术，涵盖信息收集、Web 系统渗透、中间件、操作系统和数据库系统安全测试的要点。', '29308175-1_u_2.jpg');
INSERT INTO `bs_book` VALUES (57, '9787115549976', '网络安全等级保护2.0 定级测评实施与运维', '李劲,张再武,陈佳阳 编著', '人民邮电出版社', '2021-01-01 00:00:00', 99.00, 49.50, '中国', 1, 1, '本书介绍了全新的“网络安全等级保护制度”相关规范，并具有实战项目案例，可操作性强。', '29191332-1_w_5.jpg');
INSERT INTO `bs_book` VALUES (58, '9787115567154', '白话网络安全', '翟立东', '人民邮电出版社', '2021-10-01 00:00:00', 69.90, 34.90, '中国', 1, 1, '“大东话安全”团队致力于网络安全科普，本书汇聚了团队多年从事网络安全科普活动的经验和成果。', '29305900-1_w_7.jpg');
INSERT INTO `bs_book` VALUES (59, '9787121234101', '白帽子讲Web安全（纪念版）', '吴翰清', '电子工业出版社', '2014-06-01 00:00:00', 89.00, 44.50, '中国', 1, 1, '首度以白帽子视角梳理Web安全的思想与技术，针对如何应对弱点保障安全、如何开发更安全的现代网站，详述大量真实案例并剖析攻防思考、实现过程及优劣分析。', '29246184-1_w_6.jpg');
INSERT INTO `bs_book` VALUES (60, '9787115600349', '深入浅出密码学', '戴维·王（David Wong）', '人民邮电出版社', '2023-01-01 00:00:00', 119.80, 59.90, '中国', 1, 2, '本书由资深的密码学大咖David 编写，由专业研究密码学的博士和硕士团队翻译完成。原汁原味地还原了书中关于密码学深入浅出的讲解，通过插画和简明易懂的描述，将密码学相关的知识点和实践技巧讲得通透明白。', '29504341-1_u_1.jpg');
INSERT INTO `bs_book` VALUES (61, '9787121358692', '网络安全与管理', '刘化君', '电子工业出版社', '2019-03-01 00:00:00', 59.80, 29.90, '中国', 1, 2, '本书是《网络工程师教育丛书》第6册，内容涵盖网络安全理论、攻击与防护、安全应用与网络管理，从\"攻（攻击）、防（防范）、测（检测）、控（控制）、管（管理）、评（评估）”等多个方面进行讨论。', '26924191-1_w_3.jpg');
INSERT INTO `bs_book` VALUES (62, '9787121420443', '网络安全Java代码审计实战', '高昌盛,闵海钊,等', '电子工业出版社', '2021-10-01 00:00:00', 66.00, 33.00, '中国', 1, 2, '本书是奇安信认证网络安全工程师培训教材之一，目的是为网络安全行业培养合格的人才。网络安全人才的培养是一项艰巨的任务，其中代码审计人才更是“稀缺资源”。', '29313033-1_w_2.jpg');
INSERT INTO `bs_book` VALUES (63, '9787115424914', '图解密码技术 第3版', '[日]结城浩', '人民邮电出版社', '2016-06-01 00:00:00', 89.90, 70.30, '日本', 2, 2, '畅销书全面升级！新增椭圆曲线密码、比特币等前沿内容！', '23995420-1_w_16.jpg');
INSERT INTO `bs_book` VALUES (64, '9787115441249', '网络是怎样连接的', '[日]户根勤', '人民邮电出版社', '2021-04-01 00:00:00', 69.80, 52.30, '日本', 2, 2, '日文版重印32次！“计算机网络概论”图解趣味版。蹲马桶就能看懂的网络基础知识。', '29237163-1_w_3.jpg');
INSERT INTO `bs_book` VALUES (65, '9787302479352', '密码学与网络安全（第3版）', 'Atul Kahate 著 金名 等译', '清华大学出版社', '2018-01-01 00:00:00', 79.00, 39.50, '印度', 2, 2, '以自底向上的方式介绍：从密码学到网络安全，再到案例研究。', '25201835-1_w_1.jpg');
INSERT INTO `bs_book` VALUES (66, '9787121377938', '内网安全攻防：渗透测试实战指南', '徐焱', '电子工业出版社', '2020-01-01 00:00:00', 99.00, 49.50, '中国', 2, 2, '本书由浅入深，全面、系统地讨论了常见的内网攻击手段和相应的防御方法，力求语言通俗易懂、示例简单明了，以便读者阅读领会。', '28513266-1_w_4.jpg');
INSERT INTO `bs_book` VALUES (67, '9787115610416', '网络安全防御技术与实践', '李学昭', '人民邮电出版社', '2023-05-01 00:00:00', 149.00, 111.70, '中国', 2, 3, '华为系统梳理自己的网络安全技术，汇集用户管理、加密流量检测、内容过滤、入侵防御、反病毒、DDoS攻击防范和安全沙箱七大方面。', '29571235-1_w_2.jpg');
INSERT INTO `bs_book` VALUES (68, '9787111654926', '黑客攻防从入门到精通（命令版）第2版', '武新华', '机械工业出版社', '2022-06-01 00:00:00', 69.00, 34.50, '中国', 2, 3, '简单易学：从易到难、循序渐进、图文并茂、通俗易懂 ', '28559121-1_w_3.jpg');
INSERT INTO `bs_book` VALUES (69, '9787111721222', 'CTF网络安全竞赛入门教程', '王瑞民 宋玉', '机械工业出版社', '2023-03-01 00:00:00', 69.00, 34.50, '中国', 2, 3, '资深网安专家把握CTF赛情，筛选国内外真题，串联Web渗透、逆向、密码、漏洞等核心理论，一本打通CTF要领', '29533613-1_w_1.jpg');
INSERT INTO `bs_book` VALUES (70, '9787111664475', 'Python安全攻防：渗透测试实战指南', '吴涛,方嘉明,吴荣德,徐焱', '机械工业出版社', '2023-02-01 00:00:00', 99.00, 49.50, '中国', 1, 3, '全方位掌握渗透测试编程', '29131665-1_w_4.jpg');
INSERT INTO `bs_book` VALUES (71, '9787121342837', 'Web安全攻防：渗透测试实战指南', '徐焱、李文轩、王东亚', '电子工业出版社', '2018-07-01 00:00:00', 89.00, 44.50, '中国', 1, 3, 'Web安全零基础入门，从渗透测试信息收集到后渗透攻防，安全专家实战讲解，全面介绍Web渗透核心攻击与防御方式！配免费视频', 'web_anquangongfang.jpg');
INSERT INTO `bs_book` VALUES (89, '9787513911139', '北纬78°  ', '陈丹燕', '浙江文艺出版社', '2019-09-02 15:15:33', 39.00, 19.50, '中国', 1, 1, '一个作家，一本书，激起你行走的渴望，改变你旅行的意义。陈丹燕旅行文学。', 'beiwei78.jpg');
INSERT INTO `bs_book` VALUES (90, '9787513911139', '100の东京大人味发现', '吴东龙', ' 民主与建设出版社', '2019-09-02 15:15:33', 50.00, 34.50, '中国', 1, 1, '超文艺、超时尚、很全面的东京旅游指南！台湾销售超火！从文化和设计角度深度解读东京，并提供完美的游览、住宿和美食攻略！', '100dongjindarenweifaxian.jpg');
INSERT INTO `bs_book` VALUES (91, '9787535477101', '别走，万一好笑呢', '银教授', '长江文艺出版社', '2019-09-02 15:15:33', 35.00, 26.30, '中国', 1, 1, '微博人气博主@银教授个人作品集 银教授本人含泪自荐，希望你排着队拿着笑的号码牌，按顺序笑', 'biezouwanyihaoxiaone.jpg');
INSERT INTO `bs_book` VALUES (92, '9787550019775', '此刻花开', '徐静', '百花洲文艺出版社', '2019-09-02 15:15:33', 68.00, 34.00, '中国', 1, 1, ' 一场轻松自由的创作体验！风靡全球的纸雕艺术，比《秘密花园》更给力的减压新玩法。虽然我们不断被这个世界雕刻着，但我们亦可以雕刻出一个世界！', 'cikehuakai.jpg');
INSERT INTO `bs_book` VALUES (93, '9787516413999', '洞见', '项保华', '企业管理出版社', '2019-09-02 15:15:33', 48.00, 34.60, '中国', 1, 1, '通过揭示体现在决策初心、判断、选择、落实背后的人性特征与事物规律，为提升个体及组织的决策管理水平与能力提供实用的操作指导。', 'dongjian.jpg');
INSERT INTO `bs_book` VALUES (94, '9787308164207', '腾讯传', '吴晓波', '浙江大学出版社', '2019-09-02 15:15:33', 58.00, 40.10, '中国', 1, 2, '全景式记录腾讯成长轨迹，回望一代人的互联网情怀，解读中国互联网企业领先全球的真正秘密。', 'tenxunchuan.jpg');
INSERT INTO `bs_book` VALUES (95, '9787550293151', '拉普拉斯的魔女', '东野圭吾', '北京联合出版公司', '2019-09-02 15:15:33', 39.80, 28.70, '中国', 1, 2, '东野圭吾：“我想摧毁自己以前写的小说，于是，这部作品就此诞生。”', 'lapulasidemonv.jpg');
INSERT INTO `bs_book` VALUES (96, '9787540478612', '愿你的青春不负梦想', '俞敏洪', '湖南文艺出版社', '2019-09-02 15:15:33', 36.00, 21.60, '中国', 1, 2, '50-心路历程×25-创业思考×80场演讲精华，与不甘平庸的你，谈谈如何度过不悔的青春，实现你心中的梦想。', 'yuannideqingchunbufumengxiang.jpg');
INSERT INTO `bs_book` VALUES (97, '9787540478612', '情商高，就是说话', '朱凌,常清', '延边大学出版社', '2019-09-02 15:15:33', 38.00, 19.00, '中国', 1, 2, '教你洞悉人性、说话动听！所谓情商高，就是会说话。不拆台不揭短，不生硬不伤人，让你的每一句话都说得得体又令人舒服，到哪都受欢迎！', 'qingshanggaojiushishuohuarangrenshufu.jpg');
INSERT INTO `bs_book` VALUES (98, '9787507838992', '销售心理战', '霍金斯', '中国国际广播出版社', '2019-09-02 15:15:33', 36.80, 18.40, '中国', 1, 2, '销售就是察言、观色、攻心，销售就是要搞定人，各界的销售大师们强烈推崇的销售心理学！', 'xiaoshouxinlizhan.jpg');
INSERT INTO `bs_book` VALUES (99, '9787535448569', '小道理：分寸之间', '冯仑', '长江文艺出版社', '2019-09-02 15:15:33', 42.00, 33.10, '中国', 2, 2, '商界精英的时代沉思录，地产导师的人生理想国。', 'xiaodaolifencunzhijian.jpg');
INSERT INTO `bs_book` VALUES (100, '9787508667836', '名创优品没有秘密', '杜博奇', '中信出版社', '2019-09-02 15:15:33', 36.00, 27.00, '中国', 2, 2, ' 经济寒冬中的一匹黑马，关店浪潮下的逆势崛起！全面解读名创优品的商业模式，还原一个真实的零售世界！', 'NO SECRETS.jpg');
INSERT INTO `bs_book` VALUES (101, '9787538890433', '写给-轻人的创业课', '彭帅兴', '黑龙江科学技术出版社', '2019-09-02 15:15:33', 39.80, 19.90, '中国', 2, 2, ' 每一个怀揣梦想的创业者都应该细读的暖心之作“拿来即用”的实战经验，“一针见血”的创业指导！', 'xiegeinianqinrende1.jpg');
INSERT INTO `bs_book` VALUES (102, '9787201111728', '运营笔记', '类延昊', '天津人民出版社', '2019-09-02 15:15:33', 39.80, 19.90, '中国', 2, 3, '猫扑网辉煌时代缔造者之一类类告诉你：如何在互联网运营下半场到来之前，快速成长，实现运营人生的弯道超车。', 'yunyinbiji.jpg');
INSERT INTO `bs_book` VALUES (103, '9787221135506', '太空', '亚历山德拉·米热林斯', '贵州人民出版社', '2019-09-02 15:15:33', 68.00, 45.40, '中国', 2, 3, '浩瀚宇宙万千奇观，《太空》带你探索发现！本书献给喜欢仰望星空的少-科学家和梦想家！', 'taikong.jpg');
INSERT INTO `bs_book` VALUES (104, '9787113215491', '欧洲', '亲历者》编辑部', '中国铁道出版社', '2019-09-02 15:15:33', 38.00, 29.30, '中国', 2, 3, '旅行达人实地感受，29项欧洲体验式旅行；全方位文化解读，你的欧洲之旅*精彩。', 'ouzhou.jpg');
INSERT INTO `bs_book` VALUES (105, '9787519219420', '西藏', '梅里', '世界图书出版公司', '2019-09-02 15:15:33', 39.80, 19.90, '中国', 2, 3, '西藏，一个可以改变人生的地方骑行，一种可以征服世界的方式不出门，你不知道你能走多远；不流泪，你不知道你有多坚强。西藏，一个可以改变人生的地方骑行，一种可以征服世界的方式不出门，你不知道你能走多远；不流泪，你不知道你有多坚强。', 'xizang.jpg');
INSERT INTO `bs_book` VALUES (106, '9787201111735', '我与世界只差一个你', '张皓宸', '天津人民出版社', '2019-09-02 15:15:33', 49.00, 38.70, '中国', 2, 3, '12个温馨治愈的情感故事，给-轻人爱的正能量和信心，让你在面对爱时无惧，怀疑爱时坚定。', 'woyushijiezhichayigeni.jpg');
INSERT INTO `bs_book` VALUES (107, '9787515818122', '卖产品就是卖自己', '梁汉桥', '中华工商联合出版社', '2019-09-02 15:15:33', 35.00, 17.50, '中国', 2, 3, '销售就是要玩转情商，销售就是要有效化解客户问题，销售就是要搞定人', 'maichanpinjiushimaiziji.jpg');
INSERT INTO `bs_book` VALUES (108, '9787555106920', '男孩的冒险书', '康恩·伊古尔登', '广西科学技术出版社', '2019-09-02 15:15:33', 198.00, 99.00, '中国', 2, 3, ' 有史以来给男孩的完美手册升级！英国作者献给小男子汉的重磅手绘大作！原版连续12周《纽约时报》排行榜冠军，《时代周刊》鼎力推荐！', 'nanhaidemaoxianshu.jpg');

-- ----------------------------
-- Table structure for bs_cart
-- ----------------------------
DROP TABLE IF EXISTS `bs_cart`;
CREATE TABLE `bs_cart`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NULL DEFAULT NULL,
  `book_id` int NULL DEFAULT NULL,
  `count` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_cart_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_cart_book_id`(`book_id` ASC) USING BTREE,
  CONSTRAINT `fk_cart_book_id` FOREIGN KEY (`book_id`) REFERENCES `bs_book` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_cart_user_id` FOREIGN KEY (`user_id`) REFERENCES `bs_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_cart
-- ----------------------------
INSERT INTO `bs_cart` VALUES (23, 6, 1, 1);
INSERT INTO `bs_cart` VALUES (24, 6, 2, 1);

-- ----------------------------
-- Table structure for bs_order
-- ----------------------------
DROP TABLE IF EXISTS `bs_order`;
CREATE TABLE `bs_order`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_num` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `create_date` datetime NULL DEFAULT NULL,
  `user_id` int NULL DEFAULT NULL,
  `address_id` int NULL DEFAULT NULL,
  `order_status` varchar(2) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_order_user_id`(`user_id` ASC) USING BTREE,
  INDEX `fk_order_addr_id`(`address_id` ASC) USING BTREE,
  CONSTRAINT `fk_order_addr_id` FOREIGN KEY (`address_id`) REFERENCES `bs_address` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_order_user_id` FOREIGN KEY (`user_id`) REFERENCES `bs_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_order
-- ----------------------------
INSERT INTO `bs_order` VALUES (1, 'f158ac7e-46c3-4b9c-8a80-6d89d2f190b4', '2019-10-08 08:54:58', 1, 5, '1');
INSERT INTO `bs_order` VALUES (2, '8913a7cf-8a8c-445f-a369-0df57d376994', '2019-10-08 15:17:45', 1, 1, '1');
INSERT INTO `bs_order` VALUES (3, '2019100815360001', '2019-10-08 15:36:39', 1, 1, '1');
INSERT INTO `bs_order` VALUES (4, '2019100815370001', '2019-10-08 15:37:17', 1, 4, '1');
INSERT INTO `bs_order` VALUES (5, '2023060314540001', '2023-06-03 06:54:03', 6, 7, '1');
INSERT INTO `bs_order` VALUES (6, '2023060314550001', '2023-06-03 06:55:03', 6, 7, '1');
INSERT INTO `bs_order` VALUES (7, '2023060315210001', '2023-06-03 07:21:21', 6, 7, '1');
INSERT INTO `bs_order` VALUES (8, '2023060315290001', '2023-06-03 15:29:21', 6, 7, '1');
INSERT INTO `bs_order` VALUES (9, '2023060315350001', '2023-06-03 15:35:51', 6, 7, '1');
INSERT INTO `bs_order` VALUES (10, '2023060515190001', '2023-06-05 07:19:23', 6, 7, '1');
INSERT INTO `bs_order` VALUES (11, '2023060515380001', '2023-06-05 07:38:17', 6, 7, '1');
INSERT INTO `bs_order` VALUES (12, '2023060720200001', '2023-06-07 12:20:39', 6, 8, '1');
INSERT INTO `bs_order` VALUES (13, '2023060720290001', '2023-06-07 12:29:20', 10, 9, '1');
INSERT INTO `bs_order` VALUES (14, '2023060720400001', '2023-06-07 12:40:28', 6, 8, '1');
INSERT INTO `bs_order` VALUES (15, '2023060823220001', '2023-06-08 15:22:53', 6, 8, '1');
INSERT INTO `bs_order` VALUES (16, '2023061815090001', '2023-06-18 07:09:06', 6, 8, '1');

-- ----------------------------
-- Table structure for bs_order_item
-- ----------------------------
DROP TABLE IF EXISTS `bs_order_item`;
CREATE TABLE `bs_order_item`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NULL DEFAULT NULL,
  `book_id` int NULL DEFAULT NULL,
  `count` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `fk_item_order_id`(`order_id` ASC) USING BTREE,
  INDEX `fk_book_id`(`book_id` ASC) USING BTREE,
  CONSTRAINT `fk_book_id` FOREIGN KEY (`book_id`) REFERENCES `bs_book` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_item_order_id` FOREIGN KEY (`order_id`) REFERENCES `bs_order` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_order_item
-- ----------------------------
INSERT INTO `bs_order_item` VALUES (11, 10, 57, 1);
INSERT INTO `bs_order_item` VALUES (12, 11, 62, 1);
INSERT INTO `bs_order_item` VALUES (13, 12, 1, 2);
INSERT INTO `bs_order_item` VALUES (14, 12, 2, 1);
INSERT INTO `bs_order_item` VALUES (15, 13, 1, 1);
INSERT INTO `bs_order_item` VALUES (16, 13, 2, 1);
INSERT INTO `bs_order_item` VALUES (17, 14, 2, 1);
INSERT INTO `bs_order_item` VALUES (18, 14, 62, 1);
INSERT INTO `bs_order_item` VALUES (19, 15, 1, 1);
INSERT INTO `bs_order_item` VALUES (20, 15, 57, 2);
INSERT INTO `bs_order_item` VALUES (21, 16, 68, 1);
INSERT INTO `bs_order_item` VALUES (22, 16, 69, 2);

-- ----------------------------
-- Table structure for bs_user
-- ----------------------------
DROP TABLE IF EXISTS `bs_user`;
CREATE TABLE `bs_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  `company` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bs_user
-- ----------------------------
INSERT INTO `bs_user` VALUES (1, 'jack', '123456', '1104975916@qq.com', '15200000000', '阿里巴巴');
INSERT INTO `bs_user` VALUES (2, 'tom', '123456', '1104975916@qq.com', '15250420158', '苏州市姑苏区');
INSERT INTO `bs_user` VALUES (3, 'jack1', '123456', '2037086512@qq.com', '15250420158', '苏州市姑苏区');
INSERT INTO `bs_user` VALUES (4, 'jack2', '123456', '1104975916@qq.com', '15250420158', '苏州市姑苏区');
INSERT INTO `bs_user` VALUES (5, 'registest', '123', '1@qq.com', '11111111111', '成都理工');
INSERT INTO `bs_user` VALUES (6, 'godown', '12313', '213213213', '232112', '21321');
INSERT INTO `bs_user` VALUES (7, 'godo', '123', '1321', '12312', '1321');
INSERT INTO `bs_user` VALUES (8, 'godownio', '12313', '231', '21321', '31232');
INSERT INTO `bs_user` VALUES (9, 'root', '12321', '21321', '21321', '3123');
INSERT INTO `bs_user` VALUES (10, 'root1', '12321', '21321', '21321', '3123');
INSERT INTO `bs_user` VALUES (12, 'godown2131', '12313', '213213', '2321', '2312');

SET FOREIGN_KEY_CHECKS = 1;
